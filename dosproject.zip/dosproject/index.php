<?php
include('db_connection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login_Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
 <script src="	https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
 <script src="https://kit.fontawesome.com/9a86d78b3d.js" crossorigin="anonymous"></script>
</head>
<style>
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}

.username,
.password {
  position: relative;
  display: flex;
  flex-direction: column;
  margin: 5px;
  bottom: 70px;

}

.loginform {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: white;
  margin: 20px;
  width: 530px;
  box-shadow: 0px 0px 50px 8px grey;
  border-radius: 10px;
}

.fa-user,
.fa-key {
  position: absolute;
  bottom: 12px;
  left: 7px;
  font-size: 20px;
}

.password label,
.username label {
  font-weight: 500;
}

.username input,
.password input {
  padding: 8px 30px;
  border-radius: 5px;
  border: 1px solid grey;
}

.loginbutton {
  padding: 8px 102px !important;
  position: relative;
  bottom: 70px;
}


.loginmain {
  display: flex;
  justify-content: center;
}




.fa-magnifying-glass {
  padding: 10px;
  border-radius: 0px;
}





.modal+.modal {
  z-index: 1080 !important;
}

.modal-backdrop+.modal-backdrop {
  z-index: 1070 !important;
}



.fa-arrow-right {
  /* font-weight: 500; */
  margin-left: 4px;
  font-size: 17px;
  padding: 5px 18px;
  cursor: pointer;
}

</style>
<body>
<div class="loginmain">

  <form action="" method="POST"  class="loginform">
     <img src="img/avter/login.gif" alt="" style="width:210px; height:300px;">
     <!-- <img src="login2ndgif.gif" alt="" style="width:210px;position:relative;bottom:70px;"> -->

       <div class="username">
          <label>Username:</label>
          <input type="text" name="uname" placeholder="Username">
          <i class="fa-solid fa-user"></i>
        </div>
        <div class="password">
          <label>Password:</label>
          <input type="password" name="pass" placeholder="Password">
          <i class="fa-solid fa-key"></i>
        </div>

    <button  type="submit" class="btn btn-primary loginbutton" name="login">Login</button>
  </form>
</div>



</body>
</html>


<!-- //    $pass_decode=password_verify($password, $pass1); -->

<?php 
 $conn = connectMyDB();
if(isset($_POST['login'])){
$username=$_POST['uname'];
$password=$_POST['pass'];
$select_query="SELECT * FROM login_det WHERE username='$username'";
$query=mysqli_query($conn,$select_query);
$username_search=mysqli_num_rows($query);
if($username_search){
    $username_pass=mysqli_fetch_assoc($query);
    $pass1= $username_pass['password'];

      if($password==$pass1)
      {
        echo"
        <script>
        alert('login successful');
        window.location.href='index_dashboard.php';
        </script>
        ";
     
      }else
      {
        echo"
        <script>
        alert('wrong password');
        window.location.href='index.php';
        </script>
        ";
        

      }
}
else
{
  echo"
  <script>
  alert('invalid username');
  window.location.href='index.php';
  </script>
  ";
}

}

?>
