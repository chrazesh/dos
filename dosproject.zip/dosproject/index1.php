<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
   <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
   <script src="https://kit.fontawesome.com/9a86d78b3d.js" crossorigin="anonymous"></script>
   <link rel="stylesheet" href="style.css">
   <title>Document</title>
</head>
<body>
<nav class="navigationbar bg-success">
      <div class="p-4 fs-5">
       <label for="all">ALL</label>
       <input type="checkbox" name=""  data-bs-toggle="collapse" href="#collapseExample">
      </div>
     
      <!-- multilevel dropdown starts -->
      <div class="dropdown">
      <button class="btn btn-success dropdown-toggle fs-5" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">Select Filter Option</button>
  <ul class="dropdown-menu " aria-labelledby="dropdownMenuButton">
    <li><a class="dropdown-item" id="all" href="#">All</a></li>
    <li><a class="dropdown-item">District &raquo;</a>
      <ul class="dropdown-menu dropdown-submenu submenu1">
         <?php
         $con=mysqli_connect('localhost','root','','dos');
         $selectQuery="SELECT DISTINCT `COL 4` FROM `address_1` order by `COL 4`";
         $queryPass=mysqli_query($con,$selectQuery);
         while( $result = mysqli_fetch_assoc($queryPass)){
          ?>
        <li><a class="dropdown-item" id="byDistrict" onclick="GetReport('district','<?php echo $result['COL 4']?>');"><?php echo $result["COL 4"] ?></a> </li>
        <?php
         }
        ?>
        <!-- <li><a class="dropdown-item" href="#">Submenu item 2</a></li> -->
        <!-- <li>
          <a class="dropdown-item" href="#">Submenu item 3 &raquo; </a>
          <ul class="dropdown-menu dropdown-submenu">
            <li><a class="dropdown-item" href="#">Multi level 1</a></li>
            <li><a class="dropdown-item" href="#">Multi level 2</a></li>
          </ul>
        </li> -->
        <!-- <li><a class="dropdown-item" href="#">Submenu item 4</a></li>
        <li><a class="dropdown-item" href="#">Submenu item 5</a></li> -->
      </ul>
    </li>
   
    
  </ul>
</div>   <!-- multilevel dropdown ended -->
<div class="age-grp">
<label for="" class="fs-5">From:</label>
 <input type="text">
 <label for="" class="fs-5">To:</label>
 <input type="text">
</div>
</nav>

<div class="collapse" id="collapseExample">
  <table class="display" style="width:100%;height:100%;">
   <thead>
      <tr>
         <th>Nepali Name</th>
         <th>English Name</th>
         <th>Date Of Birth in B.S</th>
         <th>Date Of Birth in A.D</th>
         <th>Gender</th> 
         <th>Nationality</th>
         <th>Education</th>
         <th>Profession</th>
         <th>Marital Status</th>
         <th>Matri Bhasa</th>
         <th>Nagrikta No.</th>
         <th>Permanent Address</th>
         <th>Temporary Address</th>
         <th>Telephone</th>
         <th>Mobile</th>
         <th>Email</th>
         <th>View</th>
      </tr>
   </thead>
   <tbody id="tbody_1">
      <?php 
      $con=mysqli_connect('localhost','root','','dos');
      $selectQuery="SELECT introductiondetails.id,introductiondetails.rName,introductiondetails.rNameCapital,introductiondetails.rDOB,introductiondetails.eDate,introductiondetails.rGender,introductiondetails.rNational,introductiondetails.rEducation,introductiondetails.rProfession,introductiondetails.rMarital,introductiondetails.rMotherToungue,introductiondetails.rCitizenshipNo,permanentaddress.rDistrict as pd,currentaddress.rDistrict as cd,currentaddress.rTelephoneNo,currentaddress.rMobileNo,currentaddress.rEmail FROM((introductiondetails INNER JOIN permanentaddress ON introductiondetails.id=permanentaddress.intro_id)INNER JOIN currentaddress on introductiondetails.id=currentaddress.intro_id);";
      $queryPass=mysqli_query($con,$selectQuery);
      $i=1;
      while( $result = mysqli_fetch_assoc($queryPass)){
         ?>
      <tr>
         <td><?php echo $result['rName']; ?></td>
         <td><?php echo $result['rNameCapital']; ?></td>
         <td><?php echo $result['rDOB']; ?> </td>
         <td><?php echo $result['eDate']; ?></td>
         <td><?php echo $result['rGender']; ?></td>
         <td><?php echo $result['rNational']; ?></td>
         <td><?php echo $result['rEducation']; ?></td>
         <td><?php echo $result['rProfession']; ?></td>
         <td><?php echo $result['rMarital']; ?></td>
         <td><?php echo $result['rMotherToungue']; ?></td>
         <td><?php echo $result['rCitizenshipNo']; ?></td>
         <td><?php echo $result['pd']; ?></td>
         <td><?php echo $result['cd']; ?></td>
         <td><?php echo $result['rTelephoneNo']; ?></td>
         <td><?php echo $result['rMobileNo']; ?></td>
         <td><?php echo $result['rEmail']; ?></td>
         <td><a href="report.php?ids=<?php echo $result['id'] ?>"><i class="fa-solid fa-eye"></i></a></td>


      </tr>
      <?php
        }
        $i++;
      ?>
   </tbody>
 </table> 
</div>
 <script>
  function GetReport(ReportBy,Value){
    $.ajax({
               url:"reportGen.php",
               method:"POST",
               data:{reportBy:ReportBy,param:Value},
               success: function (data) {
                   $("#tbody_1").empty();
                   var da = JSON.parse(data);
                   if(da.status_code == 200) {
                   $("#tbody_1").append(da.data);
                   }else if(da.status_code == 404) {
                     var html = '<tr><td class="text-center" colspan="17">'+da.message+'</td></tr>';
                     $("#tbody_1").append(html);
                   }
                 
                   }
               });
  }

   $(document).ready( function () {
    $('.display').DataTable({
       //     sorting: false,
    // ordering: false,
    // scrollY: 450,   
    // scrollX: false,  
    paging: false,
    // order:[[5,'desc']],
    // searching: false,
    dom: "Bfrtip",
   });
 $('#all').click(function () {
  $('#collapseExample').addClass("show");
  $('input[name="' + this.name + '"]').not(this).prop('checked', true);
 });


$("#showRange").click(function() {
  $(".age-grp").css("display", "block");
});

// $('#byDistrict').click(function() {

//      $con=mysqli_connect('localhost','root','','dos');
//      $selectQuery1="SELECT introductiondetails.id,introductiondetails.rName,introductiondetails.rNameCapital,introductiondetails.rDOB,introductiondetails.eDate,introductiondetails.rGender,introductiondetails.rNational,introductiondetails.rEducation,introductiondetails.rProfession,introductiondetails.rMarital,introductiondetails.rMotherToungue,introductiondetails.rCitizenshipNo,permanentaddress.rDistrict as pd,currentaddress.rDistrict as cd,currentaddress.rTelephoneNo,currentaddress.rMobileNo,currentaddress.rEmail FROM((introductiondetails INNER JOIN permanentaddress ON introductiondetails.id=permanentaddress.intro_id)INNER JOIN currentaddress on introductiondetails.id=currentaddress.intro_id);"
    
    




     

//   ?>
// });


});
 </script>
</body>
</html>

