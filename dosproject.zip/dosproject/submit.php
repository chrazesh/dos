
<?php
//  Connection to the database 
//  include('db_connection.php');
    $conn = connectMyDB();
if (isset($_POST['Save'])) {
  $_files = "";
  $image = $_POST['image_upload_file'];
  $rName = $_POST['name'];
  $rNameCapital = $_POST['nameCapital'];
  $rDOB = $_POST['dob'];
  $rEdate = $_POST['eDate'];
  $rAge = $_POST['age'];
  $Nationality = $_POST['nationality'];
  $Qualification = $_POST['qualification'];
  $Profession = $_POST['profession'];
  $Gender = $_POST['gender'];
  $SpecialAbility = $_POST['specialAbility'];
  $MarriedStatus = $_POST['maritalStatus'];
  $MotherToungue = $_POST['motherToungue'];
  $CitizenshipNo = $_POST['citizenshipNo'];
  $IssuedDate = $_POST['issuedDate'];
  $issuedLocation = $_POST['issuedLocation'];
  // $intro_id = $_POST['id'];

  // current address part 2
  $r_c_Ward = $_POST['wardNo'];
  $rProvince = $_POST['province'];
  $r_c_District = $_POST['district'];
  $rMunicipality = $_POST['municipality'];
  $rTelephone = $_POST['telephoneNo'];
  $rMobile = $_POST['mobileNo'];
  $rEmail = $_POST['email'];
  //  permanent address part 3
  $r_Ward = $_POST['pWardNo'];
  $r_Province = $_POST['province'];
  $r_District = $_POST['district'];
  $r_Municipality = $_POST['municipality'];
  $r_Telephone = $_POST['pTelephoneNo'];
  $r_Mobile = $_POST['pMobileNo'];
  $r_Email = $_POST['pEmail'];

  //  agps details part 4
  $rWard = $_POST['d_WardNo'];
  $rDistrict = $_POST['d_District'];
  $rCenter = $_POST['d_Center'];
  $rEducation = $_POST['d_QualificationYears'];
  $rSmartCardNo = $_POST['d_SmartCardNo'];

  //   language details part 5
  $rFirst_Language = $_POST['first_Language'];
  $rSecond_Language = $_POST['second_Language'];
  $rThird_Language = $_POST['third_Language'];
  $rForth_Language = $_POST['forth_Language'];

  //   Health details part 6
  $rBloodGroup = $_POST['blood_Group'];
  $rYesNo = $_POST['Yes_No'];
  $rtextField = $_POST['text_Field'];

  //   service attached details part 7
  function assign_if_exist($name)
  {
    if (isset($_POST['' . $name . ''])) {
      return $_POST['' . $name . ''];
    } else {
      return '';
    }
  }
  if (isset($_POST['1p_yes'])) {
    $rPublicity = $_POST['1p_yes'];
  } else {
    $rPublicity = '';
  }
  $rPublicity_1 = assign_if_exist('1p_yes_1');
  $rKatrine = assign_if_exist('1k_yes');
  $rKatrine_1 = assign_if_exist('1k_yes_1');
  $rPublicity1 = assign_if_exist('2p_yes');
  $rPublicity1_1 = assign_if_exist('2p_yes_1');
  $rKatrine1 = assign_if_exist('2k_yes');
  $rKatrine1_1 = assign_if_exist('2k_yes_1');
  $rPublicity2 = assign_if_exist('3p_yes');
  $rPublicity2_1 = assign_if_exist('3p_yes_1');
  $rKatrine2 = assign_if_exist('3k_yes');
  $rKatrine2_1 = assign_if_exist('3k_yes_1');
  $rPublicity3 = assign_if_exist('p_yes');
  $rPublicity3_1 = assign_if_exist('p_yes_1');
  $rMc = assign_if_exist('ac_yes');
  $rMc_1 = assign_if_exist('ac_yes_1');
  $rPublication = assign_if_exist('pra_yes');
  $rPublication_1 = assign_if_exist('pra_yes_1');
  $rIt = assign_if_exist('it_yes');
  $rIt_1 = assign_if_exist('it_yes_1');
  $rMobileTent = assign_if_exist('mo_yes');
  $rMobileTent_1 = assign_if_exist('mo_yes_1');
  $rLoverWelcome = assign_if_exist('pre_yes');
  $rLoverWelcome_1 = assign_if_exist('pre_yes_1');
  $rMustardCleaning = assign_if_exist('sir_yes');
  $rMustardCleaning_1 = assign_if_exist('sir_yes_1');
  $rVideoGraphy = assign_if_exist('vi_yes');
  $rVideoGraphy_1 = assign_if_exist('vi_yes_1');
  $rVijuli = assign_if_exist('bi_yes');
  $rVijuli_1 = assign_if_exist('bi_yes_1');
  $rSecurity = assign_if_exist('su_yes');
  $rSecurity_1 = assign_if_exist('su_yes_1');
  $rAsring = assign_if_exist('aa_yes');
  $rAsring_1 = assign_if_exist('aa_yes_1');
  $rPhotographer = assign_if_exist('pho_yes');
  $rPhotographer_1 = assign_if_exist('pho_yes_1');
  $rCoach = assign_if_exist('prashi_yes');
  $rCoach_1 = assign_if_exist('prashi_yes_1');
  $rMedical = assign_if_exist('medi_yes');
  $rMedical_1 = assign_if_exist('medi_yes_1');
  $rRegistration = assign_if_exist('regis_yes');
  $rRegistration_1 = assign_if_exist('regis_yes_1');
  $rVideoEditor = assign_if_exist('video_yes');
  $rVideoEditor_1 = assign_if_exist('video_yes_1');
  $rPublicRelations = assign_if_exist('jan_yes');
  $rPublicRelations_1 = assign_if_exist('jan_yes_1');
  $rBuyingAndSelling = assign_if_exist('kharid_yes');
  $rBuyingAndSelling_1 = assign_if_exist('kharid_yes_1');
  $rComputerOperator = assign_if_exist('computer_yes');
  $rComputerOperator_1 = assign_if_exist('computer_yes_1');
  $rAdiyeEditor = assign_if_exist('audio_yes');
  $rAdiyeEditor_1 = assign_if_exist('audio_yes_1');
  $rTranslation = assign_if_exist('trans_yes');
  $rTranslation_1 = assign_if_exist('trans_yes_1');
  $rCook = assign_if_exist('cock_yes');
  $rCook_1 = assign_if_exist('cock_yes_1');
  $rTypist = assign_if_exist('typist_yes');
  $rTypist_1 = assign_if_exist('typist_yes_1');
  $rAdiyaRecorded = assign_if_exist('a0udioRec_yes');
  $rAdiyaRecorded_1 = assign_if_exist('audioRec_yes_1');
  $rDepartmentOfServices = assign_if_exist('sewa_yes');
  $rDepartmentOfServices_1 = assign_if_exist('sewa_yes_1');
  $rKatrinHelper = assign_if_exist('kyatrin_yes');
  $rKatrinHelper_1 = assign_if_exist('kyatrin_yes_1');
  $rCultural = assign_if_exist('sans_yes');
  $rCultural_1 = assign_if_exist('sans_yes_1');
  $rLaw = assign_if_exist('kanun_yes');
  $rLaw_1 = assign_if_exist('kanun_yes_1');
  $rProduction = assign_if_exist('pro_yes');
  $rProduction_1 = assign_if_exist('pro_yes_1');
  $rAccommodation = assign_if_exist('awas_yes');
  $rAccommodation_1 = assign_if_exist('awas_yes_12');
  $rSmartCard = assign_if_exist('smart_yes');
  $rSmartCard_1 = assign_if_exist('smart_yes_1');
  $rConstruction = assign_if_exist('nirman_yes');
  $rConstruction_1 = assign_if_exist('nirman_yes_1');
  $rOfficeAssistant = assign_if_exist('office_yes');
  $rOfficeAssistant_1 = assign_if_exist('office_yes_1');
  $rAdiya = assign_if_exist('audioVideo_yes');
  $rAdiya_1 = assign_if_exist('audioVideo_yes_1');
  $rWorkShop = assign_if_exist('workshop_yes');
  $rWorkShop_1 = assign_if_exist('workshop_yes_1');
  $rGeneralService = assign_if_exist('jenral_yes');
  $rGeneralService_1 = assign_if_exist('jenral_yes_1');

  // service time details part 8
  $rLimitedTime = $_POST['limited_Time'];
  $rDuration = $_POST['duration'];
  $rCountry = $_POST['country'];
  $rInventSewa = $_POST['invent_Sewa'];
  $rEveryWeek = $_POST['every_Week'];
  $rOwnCountry1 = $_POST['own_Country1'];
  $rMoodDescription = $_POST['mood_Description'];

  if ($rName == "" || $rNameCapital == "" || $rDOB == "" || $rEdate == "" || $Nationality == "" || $Qualification == "" || $Profession == "" || $Gender == "" || $SpecialAbility == "" || $MarriedStatus == "" || $MotherToungue == "" || $CitizenshipNo == "" || $IssuedDate == "" || $issuedLocation == "") {
    $regmsg = '<div class="alert alert-danger" role="alert">
      All feilds are required!
     </div>';
  } else {
    $get_id = "SELECT case when isnull(max(id))then 1 else  (max(id))+1 end as id FROM introductiondetails;";
    $new_id = mysqli_query($conn, $get_id);
    $intro_id = '';
    if ($new_id) {
      $id = mysqli_fetch_assoc($new_id);
      // echo "my new id. ".$id['id'];
      $intro_id = $id['id'];
    } else {
      $intro_id = 1;
    }

    // introduction part 1 
    $intro_sql = "INSERT INTO `introductiondetails`(`id`,`imagepath`,`image`,`rName`, `rNameCapital`, `rDOB`,`eDate`,`rAge`, `rNational`, `rEducation`, `rProfession`, `rGender`, `rSpecialAbility`, `rMarital`, `rMotherToungue`, `rCitizenshipNo`, `rIssuedDate`, `rIssuedLocation`) VALUES ($intro_id,'$_files','$image','$rName','$rNameCapital','$rDOB','$rAge','$rEdate','$Nationality','$Qualification','$Profession','$Gender','$SpecialAbility','$MarriedStatus','$MotherToungue','$CitizenshipNo','$IssuedDate','$issuedLocation');";

    //   current address part 2 
    $current_add_sql = " INSERT INTO `currentaddress`(`intro_id`, `rWard`, `rProvince`, `rDistrict`, `rMunici`, `rTelephoneNo`, `rMobileNo`, `rEmail`) VALUES ('$intro_id','$r_c_Ward','$rProvince','$r_c_District','$rMunicipality','$rTelephone','$rMobile','$rEmail');";

    //  permanent address part 3
    $Permanent_add_sql = " INSERT INTO `permanentaddress`(`intro_id`,`rWard`, `rProvince`, `rDistrict`, `rMunici`, `rTelephoneNo`, `rMobileNo`, `rEmail`) VALUES ('$intro_id','$r_Ward','$r_Province','$r_District','$r_Municipality','$r_Telephone','$r_Mobile','$r_Email');";

    //   agps details part 4
    $agps_details_sql = " INSERT INTO `agps`(`intro_id`,`rWard`, `rDistrict`, `rCenter`, `rQualificationYears`, `rSmartCardNo`) VALUES ('$intro_id','$rWard','$rDistrict','$rCenter ','$rEducation',' $rSmartCardNo');";

    //   language details part 5
    $language_sql = " INSERT INTO `languagedetails`(`intro_id`,`rFirstLanguage`, `rSecondLanguage`, `rThirdLanguage`, `rForthLanguage`) VALUES ('$intro_id','$rFirst_Language','$rSecond_Language','$rThird_Language','$rForth_Language');";

    //    health details part 6
    $healthdetails_sql = " INSERT INTO `healthdetails`(`intro_id`,`rBloodGroup`, `rChecked`, `rWrite`) VALUES ('$intro_id','$rBloodGroup','$rYesNo','$rtextField');";

    //    service attached details part 7 
    $service_attached_sql = " INSERT INTO `serviceattacheddetails`( `intro_id`,`rPublicity`, `rPublicity_1`, `rKatrine`, `rKatrine_1`, `rPublicity1`, `rPublicity1_1`, `rKatrine1`, `rKatrine1_1`, `rPublicity2`, `rPublicity2_1`, `rKatrine2`, `rKatrine2_1`, `rPublicity3`, `rPublicity3_1`, `rMc`, `rMc_1`, `rPublication`, `rPublication_1`, `rIt`, `rIt_1`, `rMobileTent`, `rMobileTent_1`, `rLoverWelcome`, `rLoverWelcome_1`, `rMustardCleaning`, `rMustardCleaning_1`, `rVideoGraphy`, `rVideoGraphy_1`, `rVijuli`, `rVijuli_1`, `rSecurity`, `rSecurity_1`, `rAsring`, `rAsring_1`, `rPhotographer`, `rPhotographer_1`, `rCoach`, `rCoach_1`, `rMedical`, `rMedical_1`, `rRegistration`, `rRegistration_1`, `rVideoEditor`, `rVideoEditor_1`, `rPublicRelations`, `rPublicRelations_1`, `rBuyingAndSelling`, `rBuyingAndSelling_1`, `rComputerOperator`, `rComputerOperator_1`, `rAdiyeEditor`, `rAdiyeEditor_1`, `rTranslation`, `rTranslation_1`, `rCook`, `rCook_1`, `rTypist`, `rTypist_1`, `rAdiyaRecorded`, `rAdiyaRecorded_1`, `rDepartmentOfServices`, `rDepartmentOfServices_1`, `rKatrinHelper`, `rKatrinHelper_1`, `rCultural`, `rCultural_1`, `rLaw`, `rLaw_1`, `rProduction`, `rProduction_1`, `rAccommodation`, `rAccommodation_1`, `rSmartCard`, `rSmartCard_1`, `rConstruction`, `rConstruction_1`, `rOfficeAssistant`, `rOfficeAssistant_1`, `rAdiya`, `rAdiya_1`, `rWorkShop`, `rWorkShop_1`, `rGeneralService`, `rGeneralService_1`) VALUES ('$intro_id','$rPublicity','$rPublicity_1','$rKatrine','$rKatrine_1','$rPublicity1','$rPublicity1_1','$rKatrine1','$rKatrine1_1','$rPublicity2','$rPublicity2_1','$rKatrine2','$rKatrine2_1','$rPublicity3','$rPublicity3_1','$rMc','$rMc_1','$rPublication','$rPublication_1','$rIt','$rIt_1','$rMobileTent','$rMobileTent_1','$rLoverWelcome','$rLoverWelcome_1','$rMustardCleaning','$rMustardCleaning_1','$rVideoGraphy','$rVideoGraphy_1','$rVijuli','$rVijuli_1','$rSecurity','$rSecurity_1','$rAsring','$rAsring_1','$rPhotographer','$rPhotographer_1','$rCoach','$rCoach_1','$rMedical','$rMedical_1','$rRegistration','$rRegistration_1','$rVideoEditor','$rVideoEditor_1','$rPublicRelations','$rPublicRelations_1','$rBuyingAndSelling','$rBuyingAndSelling_1','$rComputerOperator','$rComputerOperator_1','$rAdiyeEditor','$rAdiyeEditor_1','$rTranslation','$rTranslation_1','$rCook','$rCook_1','$rTypist','$rTypist_1','$rAdiyaRecorded','$rAdiyaRecorded_1','$rDepartmentOfServices','$rDepartmentOfServices_1','$rKatrinHelper','$rKatrinHelper_1','$rCultural','$rCultural_1','$rLaw','$rLaw_1','$rProduction','$rProduction_1','$rAccommodation','$rAccommodation_1','$rSmartCard','$rSmartCard_1','$rConstruction','$rConstruction_1','$rOfficeAssistant','$rOfficeAssistant_1','$rAdiya','$rAdiya_1','$rWorkShop','$rWorkShop_1','$rGeneralService','$rGeneralService_1');";

    //  service time details part 8
    $service_time_sql = " INSERT INTO `servicetimedetails`(`intro_id`,`rCertainTime`, `rCertainDays`, `rCertainArea`, `rInvestmentTime`, `rInvestmentDays`, `rPlace`, `rDescription`) VALUES ('$intro_id','$rLimitedTime','$rDuration','$rCountry ','$rInventSewa','$rEveryWeek ','$rOwnCountry1','$rMoodDescription');";

    // $sql = $agps_details_sql . $language_sql . $healthdetails_sql . $service_attached_sql . $service_time_sql;
    // echo $sql; 
    if ($conn->query($intro_sql) == TRUE) {
      if ($conn->query($current_add_sql) == TRUE) {
        if ($conn->query($Permanent_add_sql) == TRUE) {
          if ($conn->query($agps_details_sql) == TRUE) {
            if ($conn->query($language_sql) == TRUE) {
              if ($conn->query($healthdetails_sql) == TRUE) {
                if ($conn->query($service_attached_sql) == TRUE) {
                  if ($conn->query($service_time_sql) == TRUE) {

                    $regmsg = '<div class="alert alert-success" role="alert">
           Data inserted successfully !!!
       </div>';
                  } else {
                    echo mysqli_error($conn);
                    $regmsg = '<div class="alert alert-danger" role="alert">
        Data has not been inserted successfully !!!
       </div>';
                  }
                }
              } else {
                $regmsg = '<div class="alert alert-danger" role="alert">
      Data has not been inserted successfully !!!
     </div>';
              }
            }

          }
        }
      }
    }
  }
}
 ?>