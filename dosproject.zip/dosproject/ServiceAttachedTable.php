<div class="row"> 
        <div class="col col-md-12">
         <table class="table" style="width:100%">

         <thead> 
            <tr>
           
            <th scope="col">प्रचार</th>
            <th scope="col">अ.</th>
            <th scope="col">ई.</th>
           
            </tr>
          </thead>
          <tbody>
            <?php
        $con=mysqli_connect('localhost','root','','dos');
        $ids=$_GET['ids'];
        $sql = "SELECT * FROM serviceattacheddetails where intro_id=$ids";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_assoc($result)
       ?>
           
            <tr>
              <td >
                <?php echo $row['rPublicity']; ?>
              </td>
              <td >
                <?php echo $row['rKatrine']; ?>
              </td>
              <td >
                <?php echo $row['rPublicity1']; ?>
              </td>
        
            </tr>
            <?php 
       
                                     

?> 

</table>
</div>
</div>
